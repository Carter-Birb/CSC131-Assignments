from game import Game

##### IMPROVEMENTS #####

# Removes items from the room when picked up by the user.

# Changed the layout of the rooms.

# Added a backstory that plays when you start the game.

# Added a way for items to be added based on items looked at.

# Renamed the rooms

g = Game()
g.play()